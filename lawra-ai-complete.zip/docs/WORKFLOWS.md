# LaWra AI - User Workflows

> Step-by-step user flows for every major feature.

---

## 📋 Table of Contents

1. [Client Management](#1-client-management)
2. [Case Management](#2-case-management)
3. [Task Management](#3-task-management)
4. [Document Factory](#4-document-factory)
5. [Legal Mind AI](#5-legal-mind-ai)
6. [Time Tracking](#6-time-tracking)
7. [Invoicing](#7-invoicing)
8. [Calendar & Events](#8-calendar--events)
9. [Knowledge Base](#9-knowledge-base)
10. [Search & Navigation](#10-search--navigation)

---

## 1. Client Management

### 1.1 Add New Client

**Trigger:** User clicks "לקוח חדש" button

**Steps:**
1. Modal/drawer slides in from right (RTL)
2. Form displays with sections:
   - **פרטים בסיסיים** (Basic Info)
     - שם (Name) - required, auto-focus
     - סוג לקוח (Type) - radio: יחיד/חברה/ממשלתי
     - ת.ז/ח.פ (ID) - optional, validates format
   - **פרטי קשר** (Contact)
     - טלפון (Phone) - LTR, validates Israeli format
     - טלפון נוסף (Secondary)
     - אימייל (Email) - LTR, validates email
     - כתובת (Address) - textarea
   - **חיוב** (Billing)
     - תעריף שעתי (Rate) - number, LTR, ₪ prefix
     - תנאי תשלום (Terms) - select: 30/60/90 days
   - **הערות** (Notes) - optional textarea

3. User fills form
4. Validation on blur and submit
5. On submit:
   - Show loading state on button
   - POST to `/api/clients`
   - On success: toast "לקוח נוסף בהצלחה", close modal, navigate to client page
   - On error: show error messages inline

**UI Components:**
- Sheet (side drawer)
- Form with react-hook-form
- Input with RTL/LTR handling
- Select for dropdowns
- Button with loading state
- Toast for notifications

### 1.2 View Client List

**Page:** `/clients`

**Layout:**
```
┌─────────────────────────────────────────────┐
│ לקוחות                    [+ לקוח חדש]      │
├─────────────────────────────────────────────┤
│ [🔍 חיפוש...] [סטטוס ▼] [סוג ▼] [מיון ▼]   │
├─────────────────────────────────────────────┤
│ ┌─────┬──────────┬───────┬────────┬──────┐ │
│ │ שם  │ טלפון    │ תיקים │ סטטוס  │ ...  │ │
│ ├─────┼──────────┼───────┼────────┼──────┤ │
│ │ ... │ ...      │ 3     │ פעיל   │ ⋯    │ │
│ │ ... │ ...      │ 1     │ ממתין  │ ⋯    │ │
│ └─────┴──────────┴───────┴────────┴──────┘ │
│                                             │
│ מציג 1-20 מתוך 45            [◀ 1 2 3 ▶]   │
└─────────────────────────────────────────────┘
```

**Interactions:**
- Click row → Navigate to client detail
- Click ⋯ → Dropdown: עריכה, מחיקה, צור תיק
- Search → Debounced filter (300ms)
- Filters → Instant update
- Pagination → URL param

### 1.3 Client Detail Page

**Page:** `/clients/[id]`

**Layout:**
```
┌─────────────────────────────────────────────┐
│ [← חזרה]  ישראל ישראלי           [⋯]       │
├───────────────┬─────────────────────────────┤
│ פרטי לקוח    │ תיקים (3)                    │
│              │ ┌──────────────────────────┐ │
│ ת.ז: 123...  │ │ כהן נגד לוי    [פעיל]   │ │
│ 📞 050-123.. │ │ CC: 12345-10-25         │ │
│ ✉️ email@... │ └──────────────────────────┘ │
│              │ ┌──────────────────────────┐ │
│ תעריף: ₪500  │ │ עסקת נדל"ן    [טיוטה]   │ │
│ תנאים: 30    │ └──────────────────────────┘ │
│              │                              │
│ [עריכה]      │ [+ תיק חדש]                  │
├───────────────┴─────────────────────────────┤
│ פעילות אחרונה                               │
│ • 03.01 - הועלה מסמך "כתב תביעה"           │
│ • 02.01 - נוספה משימה "הכנת תצהיר"         │
│ • 01.01 - תיק נפתח: כהן נגד לוי            │
└─────────────────────────────────────────────┘
```

---

## 2. Case Management

### 2.1 Create New Case

**Trigger:** "תיק חדש" from client page or cases list

**Steps:**
1. If from cases list: First show client selector
2. Multi-step form or scrollable single form:

**Step 1 - Basic Info:**
- כותרת (Title) - required
- מספר תיק (Case Number) - optional, suggest format
- סוג תיק (Type) - LITIGATION/ARBITRATION/etc
- תחום משפט (Practice Area) - dropdown

**Step 2 - Court Info:** (if LITIGATION)
- בית משפט (Court) - searchable dropdown
- שופט (Judge) - text
- צד שכנגד (Opposing Party) - text
- ב"כ צד שכנגד (Opposing Counsel) - text + phone

**Step 3 - Financials:**
- סוג שכ"ט (Fee Type) - HOURLY/FIXED/CONTINGENCY
- סכום (Amount) - conditional on type
- מקדמה (Retainer) - optional

**Step 4 - Details:**
- תאריך יעד (Deadline) - date picker
- תיאור (Description) - rich text
- תגיות (Tags) - multi-select/create

3. On submit → Create case → Navigate to case detail

### 2.2 Case Detail Page

**Page:** `/cases/[id]`

**Tab Navigation:**
```
[סקירה] [מסמכים] [משימות] [זמנים] [לוח זמנים]
```

#### Overview Tab (סקירה)

```
┌─────────────────────────────────────────────┐
│ כהן נגד לוי                    [עריכה] [⋯] │
│ CC: 12345-10-25                             │
├─────────────────────────────────────────────┤
│ סטטוס: [פעיל ▼]     עדיפות: [גבוהה ▼]      │
│ ████████████░░░░░░░░ 65%                    │
├────────────────┬────────────────────────────┤
│ לקוח           │ דוד כהן                    │
│ סוג            │ ליטיגציה - אזרחי           │
│ בית משפט       │ בית משפט השלום ת"א         │
│ שופט           │ כב' השופט ישראלי           │
│ צד שכנגד       │ משה לוי                    │
│ ב"כ צד שכנגד   │ עו"ד יעקב (054-...)        │
├────────────────┴────────────────────────────┤
│ מועדים                                      │
│ 📅 דיון הבא: 15.02.2025 09:00              │
│ ⏰ מועד אחרון: 01.06.2025                   │
├─────────────────────────────────────────────┤
│ שכ"ט                                        │
│ סוג: שעתי | תעריף: ₪500 | מקדמה: ₪5,000    │
└─────────────────────────────────────────────┘
```

#### Documents Tab (מסמכים)

```
┌─────────────────────────────────────────────┐
│ מסמכים (12)        [📤 העלאה] [📝 יצירה]   │
├─────────────────────────────────────────────┤
│ [🔍 חיפוש...] [סוג ▼]                       │
├─────────────────────────────────────────────┤
│ 📄 כתב תביעה.pdf          03.01.25   [⋯]  │
│ 📄 נספח א - חוזה.pdf      02.01.25   [⋯]  │
│ 📄 תצהיר עדות ראשית.docx  01.01.25   [⋯]  │
└─────────────────────────────────────────────┘
```

**Actions:**
- העלאה → File upload modal with drag-drop
- יצירה → Template selection → Document generator

#### Tasks Tab (משימות)

Mini Kanban board filtered to this case.

#### Time Tab (זמנים)

Time entries for this case only.

### 2.3 Change Case Status

**Quick status change from detail:**
1. Click status badge
2. Dropdown shows: טיוטה, פעיל, ממתין, מושהה, סגור, זכייה, הפסד, פשרה
3. Select new status
4. If closing (סגור/זכייה/הפסד/פשרה):
   - Confirmation dialog
   - Optional closure notes
   - Set closedDate
5. Toast confirmation

---

## 3. Task Management

### 3.1 Kanban Board

**Page:** `/tasks`

**Layout:**
```
┌────────────────────────────────────────────────────────────────┐
│ משימות                           [📊] [⚙️] [+ משימה חדשה]      │
├────────────────────────────────────────────────────────────────┤
│ [סינון: תיק ▼] [אחראי ▼] [מועד ▼]                              │
├────────────────────────────────────────────────────────────────┤
│ תיבת דואר   │ לביצוע      │ בעבודה      │ לבדיקה    │ הושלם   │
│ (3)         │ (5)         │ (2)         │ (1)       │ (8)     │
├─────────────┼─────────────┼─────────────┼───────────┼─────────┤
│ [+ הוסף]    │ [+ הוסף]    │ [+ הוסף]    │ [+ הוסף]  │         │
│             │             │             │           │         │
│ ┌─────────┐ │ ┌─────────┐ │ ┌─────────┐ │           │         │
│ │ הכנת    │ │ │ מחקר    │ │ │ כתיבת   │ │           │         │
│ │ תצהיר   │ │ │ פסיקה   │ │ │ בקשה    │ │           │         │
│ │         │ │ │         │ │ │         │ │           │         │
│ │ 09.01   │ │ │ 12.01   │ │ │ כהן..   │ │           │         │
│ │ [R][K]  │ │ │ [K]     │ │ │ [R]     │ │           │         │
│ └─────────┘ │ └─────────┘ │ └─────────┘ │           │         │
│             │             │             │           │         │
│ ┌─────────┐ │ ┌─────────┐ │             │           │         │
│ │ בדיקת   │ │ │ הגשת    │ │             │           │         │
│ │ חוזה    │ │ │ מסמכים  │ │             │           │         │
│ └─────────┘ │ └─────────┘ │             │           │         │
└─────────────┴─────────────┴─────────────┴───────────┴─────────┘
```

### 3.2 Drag and Drop

**Behavior:**
1. User grabs task card
2. Drag overlay shows card following cursor
3. Drop zones highlight when hovering
4. On drop:
   - Optimistic UI update
   - PATCH to `/api/tasks/[id]` with new status
   - PATCH to `/api/tasks/reorder` for positions
   - On error: revert to previous state + toast

**Implementation with dnd-kit:**
```tsx
<DndContext onDragEnd={handleDragEnd}>
  {columns.map(column => (
    <SortableContext items={column.tasks}>
      <TaskColumn>
        {column.tasks.map(task => (
          <SortableTaskCard key={task.id} task={task} />
        ))}
      </TaskColumn>
    </SortableContext>
  ))}
</DndContext>
```

### 3.3 Quick Add Task

**In each column header:**
1. Click [+ הוסף]
2. Inline input appears
3. Type task title + Enter
4. Task created in that column with defaults:
   - Status: column status
   - Position: 0 (top)
   - Due date: none
   - Assignee: current user
5. Toast: "משימה נוספה" with undo action

### 3.4 Task Detail Drawer

**Click task card → Opens drawer:**
```
┌─────────────────────────────────────┐
│ [×]                                 │
│                                     │
│ ☐ הכנת כתב תביעה                   │
│                                     │
│ תיאור                               │
│ ┌─────────────────────────────────┐ │
│ │ לכלול את כל הנספחים הרלוונטיים  │ │
│ │ ולהתייחס לטענות הצד שכנגד      │ │
│ └─────────────────────────────────┘ │
│                                     │
│ תיק: [כהן נגד לוי ▼]               │
│                                     │
│ אחראי: [👤 רים ▼]                  │
│                                     │
│ מועד: [📅 09.01.2025]              │
│                                     │
│ עדיפות: [🔴 גבוהה ▼]               │
│                                     │
│ הערכת זמן: [2:00 שעות]             │
│                                     │
│ ─────────────────────────────────── │
│                                     │
│ פעילות                              │
│ • רים: "התחלתי לעבוד על זה"        │
│   היום 14:30                        │
│ • יצירה: 01.01.2025                │
│                                     │
│ [הוסף תגובה...]                     │
│                                     │
│ [מחק משימה]                         │
└─────────────────────────────────────┘
```

---

## 4. Document Factory

### 4.1 Generate Document from Template

**Page:** `/documents` → Click "יצירת מסמך"

**Step 1 - Select Template:**
```
┌─────────────────────────────────────────────┐
│ בחר תבנית                                   │
├─────────────────────────────────────────────┤
│ ליטיגציה                                    │
│   📄 כתב תביעה                              │
│   📄 כתב הגנה                               │
│   📄 בקשה                                   │
│   📄 תצהיר                                  │
│                                             │
│ חוזים                                       │
│   📄 הסכם שכר טרחה                          │
│   📄 הסכם סודיות                            │
│                                             │
│ מכתבים                                      │
│   📄 מכתב התראה                             │
│   📄 חוות דעת                               │
└─────────────────────────────────────────────┘
```

**Step 2 - Select Case (optional):**
- Searchable dropdown
- Or "ללא תיק"
- Auto-populates fields from case

**Step 3 - Fill Variables:**
```
┌─────────────────────────────────────────────┐
│ כתב תביעה                                   │
├─────────────────────────────────────────────┤
│ פרטים שהוזנו אוטומטית:                      │
│ • שם התובע: דוד כהן                         │
│ • שם הנתבע: משה לוי                         │
│ • מספר תיק: CC: 12345-10-25                 │
│                                             │
│ נדרש להשלים:                                │
│ סכום התביעה: [₪ ________]                   │
│ עילת התביעה: [_______________]              │
│                                             │
│ [תצוגה מקדימה] [המשך]                       │
└─────────────────────────────────────────────┘
```

**Step 4 - Edit in Rich Editor:**
- TipTap editor with full document
- Highlight auto-filled fields
- Allow manual edits

**Step 5 - Generate:**
- Options: Save to case, Download DOCX, Send email
- AI enhancement: שפר ניסוח, הוסף אסמכתאות

### 4.2 Upload Document

**Drag-drop zone or click to browse:**
1. File selected
2. Show progress bar
3. After upload:
   - If PDF: Extract text, show summary option
   - If DOCX: Parse content
4. Form for metadata:
   - סוג מסמך (Type) - dropdown
   - תיאור (Description) - optional
5. Save → Added to case documents

### 4.3 AI Document Enhancement

**Available actions:**
- **שפר ניסוח** - Improves Hebrew legal language
- **הוסף אסמכתאות** - Suggests relevant citations
- **קצר** - Creates shorter version
- **הרחב** - Expands with more detail
- **תרגם** - Translates to English

**Flow:**
1. Select text or entire document
2. Click AI action
3. Show "מעבד..." loader
4. Display suggestions in side panel
5. Accept / Reject / Edit

---

## 5. Legal Mind AI

### 5.1 Main Chat Interface

**Page:** `/legal-mind`

**Layout:**
```
┌─────────────────────────────────────────────┐
│ Legal Mind                     [+ שיחה חדשה]│
├──────────┬──────────────────────────────────┤
│ שיחות    │                                  │
│ אחרונות  │                                  │
│          │      👋 שלום, אני לורה           │
│ • כהן... │      איך אוכל לעזור?             │
│ • מחקר   │                                  │
│ • חוזה   │                                  │
│          │                                  │
│          │                                  │
│          │                                  │
│          │                                  │
│          │                                  │
│          ├──────────────────────────────────┤
│          │ [📎] [שאל שאלה...          ] [➤]│
└──────────┴──────────────────────────────────┘
```

### 5.2 Chat Interaction

**User sends message:**
1. Message appears in chat (user bubble, left side for RTL)
2. "לורה מקלידה..." indicator
3. Response streams in (AI bubble, right side)
4. If response includes actions:
   - "יצירת משימה" → Button to create task
   - "הוספת תזכורת" → Button to add reminder
   - "ראה מסמך" → Link to document

### 5.3 Context-Aware Chat

**When accessed from case page:**
- URL: `/legal-mind?caseId=xxx`
- System prompt includes case context
- AI knows: client, case details, documents

**Example interaction:**
```
User: "מה הטענות של הצד שכנגד?"

AI: "בתיק כהן נגד לוי, הצד שכנגד העלה את הטענות הבאות:
1. התובע לא קיים את התחייבויותיו החוזיות
2. הנזק הנטען מופרז
3. טענת התיישנות

האם תרצה שאכין לך מענה לטענות אלו?"

[כן, הכן מענה] [לא תודה]
```

### 5.4 Document Summarization

**From document page → "סכם מסמך":**
1. AI reads document content
2. Generates structured summary:
   - תקציר (Summary)
   - נקודות עיקריות (Key Points)
   - גורמים מוזכרים (Entities)
   - תאריכים חשובים (Dates)
   - סכומים (Amounts)
3. Option to save summary to document metadata

---

## 6. Time Tracking

### 6.1 Manual Time Entry

**Page:** `/finance/time-entries` → Click "רישום חדש"

**Form:**
```
┌─────────────────────────────────────────────┐
│ רישום זמן חדש                               │
├─────────────────────────────────────────────┤
│ תאריך: [📅 03.01.2025]                      │
│                                             │
│ משך: [1] שעות [30] דקות                     │
│                                             │
│ תיק: [כהן נגד לוי ▼]                        │
│                                             │
│ סוג פעילות: [מחקר ▼]                        │
│   • מחקר                                    │
│   • ניסוח                                   │
│   • דיון                                    │
│   • פגישה                                   │
│   • טלפון                                   │
│   • התכתבות                                 │
│                                             │
│ תיאור: [________________________]           │
│         מחקר פסיקה בנושא...                 │
│                                             │
│ ☑️ לחיוב                                    │
│                                             │
│ [ביטול] [שמור]                              │
└─────────────────────────────────────────────┘
```

### 6.2 Timer

**Floating timer widget (optional):**
```
┌─────────────────────┐
│ ⏱️ 01:23:45        │
│ כהן נגד לוי        │
│ [⏸️] [⏹️]          │
└─────────────────────┘
```

**Start timer:**
1. Click timer icon in header
2. Select case (or no case)
3. Timer starts
4. Can minimize to corner

**Stop timer:**
1. Click stop
2. Form opens with duration pre-filled
3. Complete other fields
4. Save

### 6.3 AI Time Capture

**Via Legal Mind chat:**
```
User: "רשום שעה וחצי על מחקר בתיק כהן"

AI: "רשמתי 1:30 שעות מחקר בתיק כהן נגד לוי.
האם לסמן כשעות לחיוב?"

[✓ כן, לחיוב] [לא, פנימי]
```

---

## 7. Invoicing

### 7.1 Generate Invoice

**Page:** `/finance/invoices` → "צור חשבונית"

**Step 1 - Select Client:**
- Searchable dropdown
- Shows outstanding amount per client

**Step 2 - Select Time Entries:**
```
┌─────────────────────────────────────────────┐
│ בחר רישומי זמן לחיוב                        │
├─────────────────────────────────────────────┤
│ [☑️] 03.01 - מחקר פסיקה - 1:30 - ₪750      │
│ [☑️] 02.01 - ניסוח בקשה - 2:00 - ₪1,000    │
│ [☐] 01.01 - פגישה פנימית - 1:00 - (לא לחיוב)│
│                                             │
│ סה"כ נבחר: 3:30 שעות = ₪1,750              │
└─────────────────────────────────────────────┘
```

**Step 3 - Invoice Details:**
- מספר חשבונית (auto-generated)
- תאריך הנפקה (default: today)
- תאריך לתשלום (default: today + payment terms)
- הערות

**Step 4 - Review:**
```
┌─────────────────────────────────────────────┐
│ חשבונית מס' INV-2025-0001                   │
├─────────────────────────────────────────────┤
│ לכבוד: דוד כהן                              │
│ תאריך: 05.01.2025                           │
│ לתשלום עד: 04.02.2025                       │
├─────────────────────────────────────────────┤
│ פירוט:                                      │
│ מחקר פסיקה (1.5 שעות × ₪500)     ₪750      │
│ ניסוח בקשה (2 שעות × ₪500)       ₪1,000    │
├─────────────────────────────────────────────┤
│ סה"כ לפני מע"מ:                   ₪1,750    │
│ מע"מ (17%):                       ₪297.50   │
│ סה"כ לתשלום:                      ₪2,047.50 │
└─────────────────────────────────────────────┘
│ [ביטול] [הורד PDF] [שלח במייל] [שמור]      │
```

### 7.2 Track Payment

**From invoice detail:**
1. Click "עדכן תשלום"
2. Enter amount received
3. Update status automatically:
   - Full amount → "שולם"
   - Partial → "חלקי" + remaining
4. Log payment date

---

## 8. Calendar & Events

### 8.1 Calendar Views

**Page:** `/calendar` (or dashboard widget)

**Month View:**
- Grid with day cells
- Events shown as dots (color by type)
- Click day → Day detail
- Click event → Event detail

**Week View:**
- Hour grid
- Events as blocks
- Drag to reschedule (future)

**Agenda View:**
- List of upcoming events
- Grouped by day
- Best for mobile

### 8.2 Create Event

**Click on calendar or "אירוע חדש":**
```
┌─────────────────────────────────────────────┐
│ אירוע חדש                                   │
├─────────────────────────────────────────────┤
│ כותרת: [דיון קדם משפט]                      │
│                                             │
│ תיק: [כהן נגד לוי ▼]                        │
│                                             │
│ סוג: [⚫ דיון ▼]                            │
│   🔴 דיון                                   │
│   🟢 פגישה                                  │
│   🟠 מועד אחרון                             │
│   🔵 פנימי                                  │
│                                             │
│ תאריך: [📅 15.02.2025]                      │
│ שעה: [09:00] - [10:00]                      │
│                                             │
│ מיקום: [בית משפט השלום ת"א, אולם 5]         │
│                                             │
│ תזכורת: [☑️ שבוע לפני] [☑️ יום לפני]        │
│                                             │
│ הערות: [____________________________]       │
└─────────────────────────────────────────────┘
```

### 8.3 Court Date Workflow

**When creating event type "דיון":**
1. System auto-creates preparation tasks:
   - "הכנה לדיון" - 3 days before
   - "בדיקת מסמכים" - 1 day before
2. Send reminder to client (if enabled)
3. Block time in calendar

---

## 9. Knowledge Base

### 9.1 Browse Knowledge

**Page:** `/knowledge`

**Layout:**
```
┌─────────────────────────────────────────────┐
│ מאגר ידע                        [+ הוספה]   │
├─────────────────────────────────────────────┤
│ [🔍 חיפוש חופשי...]                         │
│                                             │
│ קטגוריות:                                   │
│ [הכל] [מאמרים] [פסקי דין] [תבניות] [נהלים] │
├─────────────────────────────────────────────┤
│ 📚 עקרונות דיני חוזים                       │
│    מאמר | אזרחי | 15.12.2024               │
│                                             │
│ ⚖️ ע"א 1234/20 פלוני נ' אלמוני             │
│    פסק דין | עליון | נזיקין                │
│                                             │
│ 📄 תבנית כתב תביעה                          │
│    תבנית | ליטיגציה                        │
└─────────────────────────────────────────────┘
```

### 9.2 Add Knowledge Item

1. Upload file or paste content
2. AI extracts:
   - Title
   - Summary
   - Key points
   - Category suggestion
   - Tags
3. Review and edit
4. Save

### 9.3 Search in Knowledge

**Full-text + Semantic search:**
1. Type query
2. Results ranked by relevance
3. Highlight matching text
4. Option to open or cite

**From Legal Mind:**
```
User: "מצא לי פסיקה בנושא הפרת חוזה"

AI: "מצאתי 3 פסקי דין רלוונטיים:
1. ע"א 1234/20 - עסק בהפרת חוזה מסחרי
2. ת"א 5678/19 - פיצויים בגין הפרה
3. ע"א 9012/18 - ביטול חוזה

האם תרצה שאסכם את אחד מהם?"
```

---

## 10. Search & Navigation

### 10.1 Global Search

**Keyboard shortcut: Ctrl/Cmd + K**

**Modal:**
```
┌─────────────────────────────────────────────┐
│ [🔍 חיפוש בכל המערכת...]                   │
├─────────────────────────────────────────────┤
│ תוצאות:                                     │
│                                             │
│ לקוחות                                      │
│   👤 דוד כהן                                │
│                                             │
│ תיקים                                       │
│   📁 כהן נגד לוי - CC: 12345-10-25         │
│                                             │
│ מסמכים                                      │
│   📄 כתב תביעה - תיק כהן                    │
│                                             │
│ משימות                                      │
│   ✓ הכנת תצהיר כהן                         │
├─────────────────────────────────────────────┤
│ [↵ לבחירה] [↑↓ ניווט] [esc לסגירה]        │
└─────────────────────────────────────────────┘
```

### 10.2 Breadcrumb Navigation

**On every page:**
```
דשבורד > תיקים > כהן נגד לוי > מסמכים
```

Each part is clickable.

### 10.3 Quick Actions

**From header or Cmd+K:**
- לקוח חדש
- תיק חדש
- משימה חדשה
- רישום זמן
- שאל את לורה

---

*Each workflow should be tested end-to-end before deployment.*
